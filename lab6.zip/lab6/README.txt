Alex Zaharia
azaharia@calpoly.edu
LAB 6

Concerns:
1. WINE, query 3: output matches, however, group_concat eliminates the space between tuple elements
2. STUDENTS, query 2: output matches, however, group_concat eliminates the space between tuple elements
3. CARS, query 3: couldn't figure out how to combine the two lists for honda and Toyota such that the correct year is showing up. See query(s) for more details
4. AIRLINES, query 4: output is not matching. I don't know what is wrong.


